import React from 'react';

/**
 * College Emblem matching the official seal on the poster:
 * "ОДЕСЬКА МОРСЬКА АКАДЕМІЯ • НАЦІОНАЛЬНИЙ УНІВЕРСИТЕТ"
 * Training tall ship with billowing sails, rope frame, anchors.
 */
export const CollegeSealSVG: React.FC<{ size?: number; className?: string }> = ({
  size = 72,
  className = '',
}) => {
  return (
    <div style={{ width: size, height: size }} className={`relative select-none ${className}`}>
      <svg viewBox="0 0 200 200" className="w-full h-full drop-shadow-md" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="goldSealGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="40%" stopColor="#d4af37" />
            <stop offset="80%" stopColor="#a16207" />
            <stop offset="100%" stopColor="#713f12" />
          </linearGradient>
          <radialGradient id="skySeaGrad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#7dd3fc" />
            <stop offset="55%" stopColor="#0284c7" />
            <stop offset="100%" stopColor="#075985" />
          </radialGradient>
        </defs>

        {/* Rope Outer Border */}
        <circle cx="100" cy="100" r="95" fill="none" stroke="url(#goldSealGrad)" strokeWidth="6" strokeDasharray="6,4" />
        <circle cx="100" cy="100" r="90" fill="#0f172a" stroke="url(#goldSealGrad)" strokeWidth="2" />

        {/* Outer text path circle */}
        <path id="sealTextPath" d="M 100,20 A 80,80 0 1,1 99.9,20" fill="none" />
        
        {/* Navy Ring */}
        <circle cx="100" cy="100" r="82" fill="#0b2341" stroke="#fbbf24" strokeWidth="1.5" />

        {/* Inner Sky & Sea circle */}
        <circle cx="100" cy="100" r="58" fill="url(#skySeaGrad)" stroke="#d4af37" strokeWidth="2" />

        {/* Sun & Sea Horizon */}
        <path d="M 42,108 Q 100,112 158,108 L 158,158 L 42,158 Z" fill="#0369a1" />
        <circle cx="100" cy="85" r="14" fill="#fef08a" opacity="0.8" />

        {/* 3-Masted Tall Training Sailing Ship (Навчальне вітрильне судно) */}
        <g transform="translate(100, 96) scale(0.65)">
          {/* Black Hull */}
          <path d="M -50,15 L 45,15 L 40,28 L -45,28 Z" fill="#0f172a" stroke="#ffffff" strokeWidth="1.5" />
          <line x1="-48" y1="21" x2="42" y2="21" stroke="#ffffff" strokeWidth="1.5" />
          {/* Masts */}
          <line x1="-25" y1="15" x2="-25" y2="-40" stroke="#f8fafc" strokeWidth="2" />
          <line x1="0" y1="15" x2="0" y2="-48" stroke="#f8fafc" strokeWidth="2.5" />
          <line x1="25" y1="15" x2="25" y2="-38" stroke="#f8fafc" strokeWidth="2" />
          {/* White Sails */}
          <path d="M -23,-36 L -5,-36 L -10,-24 L -23,-24 Z" fill="#ffffff" />
          <path d="M -23,-20 L -3,-20 L -8,-8 L -23,-8 Z" fill="#ffffff" />
          <path d="M 2,-44 L 20,-44 L 16,-32 L 2,-32 Z" fill="#ffffff" />
          <path d="M 2,-28 L 22,-28 L 18,-14 L 2,-14 Z" fill="#ffffff" />
          <path d="M 2,-10 L 24,-10 L 20,4 L 2,4 Z" fill="#ffffff" />
          <path d="M 27,-34 L 42,-34 L 38,-22 L 27,-22 Z" fill="#ffffff" />
          <path d="M 27,-18 L 40,-18 L 36,-6 L 27,-6 Z" fill="#ffffff" />
          {/* Jib sails */}
          <polygon points="-25,-32 -48,15 -25,12" fill="#ffffff" opacity="0.9" />
        </g>

        {/* Top Arc College Label */}
        <text fill="#fef08a" fontSize="8.5" fontWeight="bold" letterSpacing="0.8" fontFamily="'Montserrat', sans-serif">
          <textPath href="#sealTextPath" startOffset="50%" textAnchor="middle">
            • ОДЕСЬКА МОРСЬКА АКАДЕМІЯ •
          </textPath>
        </text>

        {/* Anchor at bottom */}
        <g transform="translate(100, 186) scale(0.4)" stroke="#fef08a" fill="none" strokeWidth="3">
          <line x1="0" y1="-14" x2="0" y2="10" />
          <circle cx="0" cy="-16" r="3.5" />
          <path d="M -10,3 C -10,12 10,12 10,3" strokeWidth="3" />
        </g>
      </svg>
    </div>
  );
};

/**
 * State Coat of Arms of Ukraine (Тризуб) in golden maritime frame
 */
export const TridentBadgeSVG: React.FC<{ size?: number; className?: string }> = ({
  size = 58,
  className = '',
}) => {
  return (
    <div style={{ width: size, height: size }} className={`relative select-none ${className}`}>
      <svg viewBox="0 0 100 120" className="w-full h-full drop-shadow-md" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="tridentGold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="50%" stopColor="#eab308" />
            <stop offset="100%" stopColor="#a16207" />
          </linearGradient>
        </defs>

        {/* Shield background (Blue & Gold) */}
        <path
          d="M 10,15 Q 50,5 90,15 L 90,65 Q 90,105 50,118 Q 10,105 10,65 Z"
          fill="#0c4a6e"
          stroke="url(#tridentGold)"
          strokeWidth="3.5"
        />

        {/* Stylized Golden Trident (Тризуб) */}
        <g fill="none" stroke="url(#tridentGold)" strokeWidth="3.8" strokeLinecap="round" strokeLinejoin="round">
          {/* Center spear */}
          <line x1="50" y1="28" x2="50" y2="88" strokeWidth="4.5" />
          <path d="M 45,36 L 50,26 L 55,36" fill="url(#tridentGold)" />
          {/* Left blade */}
          <path d="M 32,38 C 32,72 44,82 50,88" />
          <path d="M 32,38 L 28,45 L 35,46 Z" fill="url(#tridentGold)" />
          {/* Right blade */}
          <path d="M 68,38 C 68,72 56,82 50,88" />
          <path d="M 68,38 L 72,45 L 65,46 Z" fill="url(#tridentGold)" />
          {/* Inner connecting arches */}
          <path d="M 40,56 C 44,52 46,52 50,56 C 54,52 56,52 60,56" />
          <path d="M 38,72 C 44,78 46,78 50,78 C 54,78 56,78 62,72" />
        </g>
      </svg>
    </div>
  );
};

/**
 * Cadet 611 Group Anchor Crest
 */
export const CadetGroupBadgeSVG: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`inline-flex items-center gap-2 bg-[#091e38] px-3.5 py-1.5 rounded-lg border border-amber-400/50 shadow-md ${className}`}>
      <svg width="22" height="22" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="50" cy="50" r="46" fill="#1e3a5f" stroke="#f59e0b" strokeWidth="5" />
        <g stroke="#fef08a" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" fill="none">
          <line x1="50" y1="18" x2="50" y2="76" />
          <circle cx="50" cy="14" r="7" strokeWidth="5" />
          <line x1="28" y1="36" x2="72" y2="36" strokeWidth="7" />
          <path d="M 22,54 C 22,82 78,82 78,54" strokeWidth="8" />
          <polygon points="18,52 26,52 22,44" fill="#fef08a" stroke="none" />
          <polygon points="82,52 74,52 78,44" fill="#fef08a" stroke="none" />
        </g>
      </svg>
      <div className="flex flex-col text-left">
        <span className="text-[10px] uppercase font-bold text-amber-300 tracking-wider font-mono">ВСП ДФК НУ ОМА</span>
        <span className="text-xs font-black text-white tracking-widest font-nautical">611 ГРУПА</span>
      </div>
    </div>
  );
};
