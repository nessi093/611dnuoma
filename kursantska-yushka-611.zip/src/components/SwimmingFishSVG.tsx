import React, { useState } from 'react';
import { playBubbleSound } from '../utils/audio';

export const SwimmingFishSVG: React.FC = () => {
  const [bubbles, setBubbles] = useState<Array<{ id: number; x: number; y: number }>>([]);

  const handleFishClick = (e: React.MouseEvent) => {
    playBubbleSound();
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setBubbles((prev) => [...prev.slice(-6), { id: Date.now(), x, y }]);
  };

  return (
    <div
      onClick={handleFishClick}
      title="Натисніть на дунайську рибку!"
      className="relative w-full h-24 overflow-hidden pointer-events-auto cursor-pointer select-none bg-gradient-to-b from-[#0a192f] via-[#0d2847] to-[#040e1a]"
    >
      {/* Swimming Danube Fish 1 (Sudak / Pikeperch) */}
      <div
        className="absolute top-4 -left-24 animate-fish"
        style={{ animationDuration: '28s', animationDelay: '0s' }}
      >
        <svg width="84" height="42" viewBox="0 0 160 80" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="sudakGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#475569" />
              <stop offset="40%" stopColor="#94a3b8" />
              <stop offset="80%" stopColor="#cbd5e1" />
              <stop offset="100%" stopColor="#f1f5f9" />
            </linearGradient>
          </defs>
          {/* Fish Body */}
          <path
            d="M 140,40 C 110,20 60,20 20,40 C 60,60 110,60 140,40 Z"
            fill="url(#sudakGrad)"
            stroke="#334155"
            strokeWidth="1.5"
          />
          {/* Dorsal Fin with spikes */}
          <path d="M 60,22 L 75,8 L 90,14 L 105,10 L 115,24 Z" fill="#64748b" opacity="0.8" />
          {/* Tail Fin with wagging motion */}
          <path
            d="M 22,40 L 4,20 Q 14,40 4,60 Z"
            fill="#475569"
            className="animate-wing"
            style={{ transformOrigin: '22px 40px' }}
          />
          {/* Pectoral Fin */}
          <path d="M 100,42 Q 85,55 90,62 Q 105,52 100,42 Z" fill="#94a3b8" opacity="0.75" />
          {/* Eye */}
          <circle cx="132" cy="36" r="4.5" fill="#fef08a" stroke="#1e293b" strokeWidth="1" />
          <circle cx="133" cy="36" r="2.5" fill="#0f172a" />
          {/* Gills */}
          <path d="M 116,28 Q 112,40 118,52" fill="none" stroke="#64748b" strokeWidth="1.8" />
          {/* Scales markings */}
          <path d="M 75,32 Q 80,40 75,48 M 88,30 Q 93,38 88,46 M 60,35 Q 65,40 60,45" stroke="#64748b" strokeWidth="1" fill="none" opacity="0.5" />
        </svg>
      </div>

      {/* Swimming Danube Fish 2 (Golden Danube Carp / Короп) */}
      <div
        className="absolute top-10 -left-20 animate-fish"
        style={{ animationDuration: '34s', animationDelay: '12s' }}
      >
        <svg width="74" height="38" viewBox="0 0 160 80" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="carpGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#b45309" />
              <stop offset="50%" stopColor="#f59e0b" />
              <stop offset="90%" stopColor="#fde68a" />
              <stop offset="100%" stopColor="#fef3c7" />
            </linearGradient>
          </defs>
          <path
            d="M 135,40 C 105,15 50,18 18,40 C 50,62 105,65 135,40 Z"
            fill="url(#carpGrad)"
            stroke="#78350f"
            strokeWidth="1.5"
          />
          {/* Dorsal Fin */}
          <path d="M 55,20 C 70,10 95,12 110,22 Z" fill="#d97706" />
          {/* Tail Fin */}
          <path
            d="M 20,40 L 2,18 C 12,38 12,42 2,62 Z"
            fill="#d97706"
            className="animate-wing"
            style={{ transformOrigin: '20px 40px' }}
          />
          {/* Eye */}
          <circle cx="126" cy="35" r="4.5" fill="#fef08a" stroke="#451a03" strokeWidth="1" />
          <circle cx="127" cy="35" r="2.2" fill="#18181b" />
          {/* Whisker barbels */}
          <path d="M 134,44 Q 140,52 135,58" stroke="#f59e0b" strokeWidth="1.5" fill="none" />
        </svg>
      </div>

      {/* Floating Bubbles on click */}
      {bubbles.map((b) => (
        <span
          key={b.id}
          className="absolute w-4 h-4 rounded-full border border-sky-300 bg-sky-200/40 animate-ping pointer-events-none"
          style={{ left: b.x - 8, top: b.y - 8 }}
        />
      ))}

      {/* Bottom Subtitle Indicator */}
      <div className="absolute right-4 bottom-1 text-[10px] text-sky-400/60 font-mono tracking-wider">
        ≈ Дунайські глибини: жива риба для нашої юшки ≈
      </div>
    </div>
  );
};
