import React, { useState } from 'react';
import { CauldronSVG } from './CauldronSVG';
import { playBubbleSound } from '../utils/audio';

export const CauldronFeatureSection: React.FC = () => {
  const [stirEffect, setStirEffect] = useState(false);

  const handleStir = () => {
    playBubbleSound();
    setStirEffect(true);
    setTimeout(() => setStirEffect(false), 800);
  };

  return (
    <section id="cauldron" className="py-16 bg-[#040e1a] relative border-b border-amber-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-400/40 text-amber-300 text-xs font-bold uppercase tracking-wider mb-3">
            <span>🔥</span> Головна страва ярмарку
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black font-nautical text-white">
            Казан Курсантської Юшки (5 л)
          </h2>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            Курсанти 611 групи ДФК НУ ОМА готують справжню рибальську юшку на живому вогні прямо на подвір'ї коледжу! 5 літрів наваристого бульйону зі свіжої риби, часниковим саламауром та польовим димком.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Animated SVG Cauldron Display */}
          <div className="lg:col-span-6 flex flex-col items-center">
            <div className="relative w-full max-w-lg bg-[#07192f] p-6 rounded-3xl border-2 border-amber-500/40 shadow-2xl text-center">
              <div className="mb-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-widest font-mono">
                  Казан 5 Літрів • Камбуз 611
                </span>
                <h3 className="text-lg font-bold text-white">
                  Гаряча юшка на живому вогні
                </h3>
                <p className="text-xs text-slate-400">
                  Натисніть на казан, щоб помішати юшку!
                </p>
              </div>

              {/* Animated SVG Cauldron with Steam & Bubbles */}
              <div className="my-2">
                <CauldronSVG isStirring={stirEffect} onStir={handleStir} className="w-full max-w-[340px] mx-auto" />
              </div>

              <div className="mt-4 pt-3 border-t border-slate-700/60 flex items-center justify-center gap-6 text-xs text-amber-300 font-medium">
                <span className="flex items-center gap-1.5">
                  <span>🍲</span> Об'єм: 5 літрів
                </span>
                <span className="flex items-center gap-1.5">
                  <span>🐟</span> Свіжа риба
                </span>
                <span className="flex items-center gap-1.5">
                  <span>🧄</span> Саламаур
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Recipe Secrets & Tradition */}
          <div className="lg:col-span-6 space-y-4">
            <h3 className="text-xl font-bold font-nautical text-amber-300">
              Секрети нашої юшки
            </h3>

            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-[#081b33] border border-amber-500/20 flex gap-3.5">
                <div className="text-2xl flex-shrink-0">🍲</div>
                <div>
                  <h4 className="text-sm font-bold text-white">5-літровий казан</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Юшка вариться порційно у чавунному казані, що забезпечує ідеальний баланс наваристості, спецій та тепла.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#081b33] border border-amber-500/20 flex gap-3.5">
                <div className="text-2xl flex-shrink-0">🪵</div>
                <div>
                  <h4 className="text-sm font-bold text-white">Аромат димку</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Вогонь із сухих дубових полін надає юшці той самий неповторний польовий аромат привалів та походів.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#081b33] border border-amber-500/20 flex gap-3.5">
                <div className="text-2xl flex-shrink-0">🧄</div>
                <div>
                  <h4 className="text-sm font-bold text-white">Часниковий саламаур</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Додається до кожної тарілочки: пікантна заправка з розтертого часничку, перцю та міцного бульйону.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#092244] border border-amber-400/40 text-center">
              <span className="text-xs font-bold uppercase text-amber-300 tracking-wider block font-mono">
                Організатор: ДФК НУ ОМА
              </span>
              <p className="text-xs text-slate-200 mt-1">
                2 жовтня об 11:00 на подвір'ї коледжу (Проспект Миру, 9). Запрошуємо всіх скуштувати гарячу юшку!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
